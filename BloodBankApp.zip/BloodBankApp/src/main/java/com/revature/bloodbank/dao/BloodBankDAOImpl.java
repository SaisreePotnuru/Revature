package com.revature.bloodbank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.revature.bloodbank.client.BloodbankApplication;
import com.revature.bloodbank.model.BloodBankCenter;
import com.revature.bloodbank.util.DBUtil;


public class BloodBankDAOImpl  implements BloodBankDAO {
	static  Logger logger=Logger.getLogger(BloodBankDAOImpl.class);
	//adding blood bank center 
	public void addBloodBankCenter(BloodBankCenter bloodBankCenter)  {
		
		try {
			Connection con=DBUtil.getConnection();
			PreparedStatement pst=con.prepareStatement("insert into BloodBankCenter values(?,?,?,?,?,?)");
			
			pst.setInt(1, bloodBankCenter.getCenterId());
			pst.setString(2, bloodBankCenter.getCenterName());
			pst.setString(3, bloodBankCenter.getStreet());
			pst.setString(4, bloodBankCenter.getCity());
			pst.setString(5, bloodBankCenter.getState());
			pst.setInt(6, bloodBankCenter.getPincode());
			boolean i=pst.execute();
			//checking the execution of prepared statement
			if(i==false){
				logger.info("A record is added in table");
				System.out.println("record inserted successfully");
			}
			else
			{
				logger.error("Record with same id already exists");
				System.out.println("Id already exists");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}	
	}
	//deleting bloodbank center 
	public void deleteBloodBankCenter(int id){
	try{
		Connection con=DBUtil.getConnection();
		PreparedStatement pstdel=con.prepareStatement("delete from BloodBankCenter where id=?");
		pstdel.setInt(1, id);
		int i=pstdel.executeUpdate();
		if(i>0)//checking whether the id is existed in table or not
		{
			logger.info("record is deleted ");
			System.out.println("record deleted successfully");
		}
		else
		{
				logger.error("record is not found");
				System.out.println("No such record found in database");
		}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		
	}
	//updating name of blood bank center
	public void updateBloodBankCenter(int id,String name)
	{
		try{
			Connection con=DBUtil.getConnection();
			
			PreparedStatement pstupdate=con.prepareStatement("update BloodBankCenter  set name=? where id=?");
			pstupdate.setInt(2,id);
			pstupdate.setString(1,name);
			int i=pstupdate.executeUpdate();
			if(i>0)//checking the id is present or not in the table
			{
				logger.info("Record is updated");
				System.out.println("record updated successfully");
			}
			else
			{
				logger.error("Unable to update record");
				System.out.println("No such record found in database");
			}
			}catch(Exception e){
				System.out.println(e.getMessage());
			}
		
	}
	//displaying the list of blood bank centers
	public List<BloodBankCenter> getAllcenters() {
		List<BloodBankCenter> bloodbankcenterslist=new ArrayList<BloodBankCenter>();
		try{
			Connection con=DBUtil.getConnection();
			Statement ps=con.createStatement();
			ResultSet  rs=ps.executeQuery("select * from BloodBankCenter ");
			while(rs.next()){
				BloodBankCenter b=new BloodBankCenter();
				b.setCenterId(rs.getInt("id"));
				b.setCenterName(rs.getString("name"));
				b.setStreet(rs.getString("street"));
				b.setCity(rs.getString("city"));
				b.setState(rs.getString("state"));
				b.setPincode(rs.getInt("pincode"));
				bloodbankcenterslist.add(b);
			}
		}catch(Exception e){
			System.out.println(e);
		}
		return bloodbankcenterslist;
	}
	//displaying the list of blood bank center with respect to id
	public List<BloodBankCenter> getCenterById(int id) {
		// TODO Auto-generated method stub
		List<BloodBankCenter> bloodbankcenterlistbyid=new ArrayList<BloodBankCenter>();
		try{
			Connection con=DBUtil.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from bloodbankcenter where id=?",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ps.setInt(1,id);
			ResultSet  rs=ps.executeQuery();
			if(rs.next()==false)
			{
				System.out.println("No such record in database");
			}
			else{
				rs.previous();
				while(rs.next()){
					BloodBankCenter b=new BloodBankCenter();
					b.setCenterId(rs.getInt(1));
					b.setCenterName(rs.getString(2));
					b.setStreet(rs.getString(3));
					b.setCity(rs.getString(4));
					b.setState(rs.getString(5));
					b.setPincode(rs.getInt(6));
					bloodbankcenterlistbyid.add(b);
				}
			}
			
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return bloodbankcenterlistbyid;
	}

}
