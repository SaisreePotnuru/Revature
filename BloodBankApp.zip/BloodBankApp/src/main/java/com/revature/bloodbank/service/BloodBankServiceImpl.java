package com.revature.bloodbank.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.revature.bloodbank.dao.BloodBankDAO;
import com.revature.bloodbank.dao.BloodBankDAOImpl;
import com.revature.bloodbank.model.BloodBankCenter;

public class BloodBankServiceImpl implements BloodBankService
{
	static  Logger logger=Logger.getLogger(BloodBankServiceImpl.class);
	BloodBankDAO bloodBankDaoImpl=new BloodBankDAOImpl();
	
	public void addBloodBankCenter(BloodBankCenter bloodBankCenter){
		logger.info("In Service for adding.....");
		try {
			bloodBankDaoImpl.addBloodBankCenter(bloodBankCenter);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void deleteBloodBankCenter(int id){
		logger.info("In Service for deleting....");
		try{
			bloodBankDaoImpl.deleteBloodBankCenter(id);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void updateBloodBankCenter(int id,String name) {
		logger.info("In Service for updation......");
		try{
			bloodBankDaoImpl.updateBloodBankCenter(id,name);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public List<BloodBankCenter> getAllcenters(){
		logger.info("In Service for displaying all lists.....");
		return bloodBankDaoImpl.getAllcenters();
		
	}

	public List<BloodBankCenter> getCenterById(int id){
		logger.info("In Service for displaying details of specific id.......");
			return bloodBankDaoImpl.getCenterById(id);
	}
}
