package com.ers.exception;

public class InvalidRequestException {

}
  


/*<!DOCTYPE hibernate-configuration SYSTEM 
"http://www.hibernate.org/dtd/hibernate-configuration-3.0.dtd">*/

