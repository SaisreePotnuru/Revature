package com.ers.bo;

public class EmployeeValidator {
	
	public boolean checkId() {
		return true;
	}
	public boolean checkUserName() {
		return true;
	}
}