package com.ers.exception;

public class InvalidRequestException {

}
