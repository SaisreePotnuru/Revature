package com.ers.exception;

public class EmployeeNotFoundException {

}
